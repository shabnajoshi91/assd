package com.ceino.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ServiceClass {
	public static Connection connect = null;

//	public static void main(String[] args) {
//		conclass();
//
//	}

	public static Connection conclass() {

		if (connect != null) {
			System.out.println("Connected");
			return connect;
		} else {
			System.out.println("need to connect");

			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}


			try {
				connect = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/Animal", "root", "root");

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return connect;
	}
}
