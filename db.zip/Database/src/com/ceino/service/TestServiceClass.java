package com.ceino.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.ceino.model.AnimalModel;

public class TestServiceClass {

	Connection con = ServiceClass.conclass();

	Statement st;
	ResultSet rs;

	public ArrayList<AnimalModel> animalView() {

		ArrayList<AnimalModel> animod = new ArrayList<AnimalModel>();

		try {
			String sql = "select * from animal_details";
			st = con.createStatement();
			rs = st.executeQuery(sql);

			while (rs.next()) {
				AnimalModel am = new AnimalModel();
				am.setName(rs.getString(1));
				am.setType(rs.getString(2));
				am.setAge(rs.getString(3));
				am.setId(rs.getInt(4));
				animod.add(am);

				/*
				 * System.out.print(rs.getString(2));
				 * System.out.print(", "+rs.getString(3));
				 * System.out.print(", "+rs.getString(4));
				 */
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(animod);
		return animod;

	}

	public void insertIntoTable(ArrayList<AnimalModel> animlist) {

		for (AnimalModel am : animlist) {

			try {

				String sql = "insert into animal_details(name, type, age)"
						+ "values('" + am.getName() + "','" + am.getType()
						+ "','" + am.getAge() + "')";
				st = con.createStatement();
				st.executeUpdate(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// public void deleteRow(int id) {
	// ArrayList<AnimalModel> animlist = new ArrayList<AnimalModel>();
	// for (AnimalModel am : animlist) {
	//
	// String sql = "delete from animal_details where id ='"+id+"'";
	// try {
	// st = con.createStatement();
	// st.executeUpdate(sql);
	// } catch (SQLException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// }
	// }

	public void deleteRow(int deleteIndex) {

		/*try {
			String sql = "delete from animal_details where id ='" + id + "'";
			// System.out.println("delete from animal_details where id ='"+id+"'");
			st = con.createStatement();
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		try {
			
			String sql = "select * from animal_details";
			st = con.createStatement();
			rs = st.executeQuery(sql);

			int i=0;
			
			while (rs.next()) {
				
				//System.out.println("i "+i);
				if (deleteIndex == i) {
					
					
					String id =rs.getString(4);
//					System.out.println("id of database "+id);
					String sql1 = "delete from animal_details where id ='"+id+"'";
					st = con.createStatement();
					st.executeUpdate(sql1);
				}
			i++;
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	// public void deleteRow(int id) {
	// AnimalModel am = new AnimalModel();
	// try {
	// String sql1 = "delete from animal_details where id = id ='"
	// + am.getId() + "'";
	// st = con.createStatement();
	// st.executeUpdate(sql1);
	//
	// int i = 0;
	// while (rs.next()) {
	// am.setId(rs.getInt(4));
	// if (id == i) {
	// // delete query
	//
	// String sql = "select * from animal_details";
	// st = con.createStatement();
	// rs = st.executeQuery(sql);
	//
	// }
	// i++;
	// }
	//
	// } catch (Exception e) {
	// // TODO: handle exception
	// }
	//
	//
	// String sql = "delete from animal_details where id ='"+id+"'";
	//
	// try { st = con.createStatement();
	//
	// st.executeUpdate(sql); } catch (SQLException e) {
	// e.printStackTrace(); }
	//
	// }

	public void removeValues() {
		try {
			String sql = "truncate animal_details";
			st = con.createStatement();
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void deleteUnfilledRow() {

		try {
			String sql = "delete from animal_details where name='null'";
			st = con.createStatement();
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	// public static void main(String[] args) {
	// AnimalModel am = new AnimalModel();
	// TestServiceClass tc = new TestServiceClass();
	// tc.deleteRow(am.getId());
	// tc.animalView();
	// }

}
