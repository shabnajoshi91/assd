package com.ceino.animal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class TestClass {

	private Table table;

	private static Connection connect;
	private static Statement statement;
	private static ResultSet resultSet;

	public static void main(String[] args) {
		try {
			TestClass window = new TestClass();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void open() {
		Display display = Display.getDefault();
		Shell shell = new Shell();
		shell.setLayout(new GridLayout(1, false));
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		{
			table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION
					| SWT.VIRTUAL);
			table.setHeaderVisible(true);
			table.setItemCount(100);
			table.addListener(SWT.SetData, new Listener() {
				public void handleEvent(Event event) {
					TableItem item = (TableItem) event.item;

					try {
						Class.forName("com.mysql.jdbc.Driver");
						connect = DriverManager.getConnection(
								"jdbc:mysql://localhost:3306/Animal", "root", "root");
						System.out.println("Connecting succesfully");
						statement = connect.createStatement();
						resultSet = statement
								.executeQuery("Select * from animal_details");
						while (resultSet.next()) {
							item.setText(new String[] { resultSet.getString(1),
									resultSet.getString(2),
									resultSet.getString(3),
									resultSet.getString(4) });
						}
					} catch (Exception e) {
						System.out.println("Cannot connect to database server");
					}

				}
			});

			table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1,
					1));
			{
				TableColumn tblclmnEno = new TableColumn(table, SWT.NONE);
				tblclmnEno.setWidth(100);
				tblclmnEno.setText("id");
			}
			{
				TableColumn tblclmnEname = new TableColumn(table, SWT.NONE);
				tblclmnEname.setWidth(100);
				tblclmnEname.setText("name");
			}
			{
				TableColumn tblclmnAge = new TableColumn(table, SWT.NONE);
				tblclmnAge.setWidth(100);
				tblclmnAge.setText("type");
			}
			{
				TableColumn tblclmnPosition = new TableColumn(table, SWT.NONE);
				tblclmnPosition.setWidth(100);
				tblclmnPosition.setText("age");
			}

		}

		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
}
