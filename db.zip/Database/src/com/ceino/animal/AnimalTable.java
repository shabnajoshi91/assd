package com.ceino.animal;

import java.io.IOException;
import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import com.ceino.model.AnimalModel;
import com.ceino.service.TestServiceClass;

public class AnimalTable {

	static Button save;
	static Button delete;
	static Button removesheet;
	static Button view;
	Table table;

	static AnimalTable ui = new AnimalTable();

	ArrayList<AnimalModel> animalModels = new ArrayList<AnimalModel>();

	public void test() {

		TestServiceClass tsc = new TestServiceClass();
		animalModels = tsc.animalView();

		for (int r = 0; r < 10; r++) {
			TableItem item = new TableItem(table, SWT.NONE);
			if (r < animalModels.size()) {
				AnimalModel animal = animalModels.get(r);
				for (int c = 0; c < table.getColumnCount(); c++) {
					item.setText(new String[] { "" + animal.getId(),
							"" + animal.getName(), "" + animal.getType(),
							"" + animal.getAge() });
				}

			}
		}

	}

	public void viewButtonSelect(Shell shell) {

		try {
			ui.viewTable(shell);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		shell.redraw();
		shell.layout();
	}

	public static void main(String[] args) throws IOException {

		final Display display = new Display();
		final Shell shell = new Shell(display);
		FormLayout gridLayout = new FormLayout();
		shell.setLayout(gridLayout);
		shell.setText("Animal Table");

		final Shell _shell = new Shell(Display.getDefault().getActiveShell(),
				SWT.NO_FOCUS | SWT.NO_TRIM);
		_shell.setBackgroundMode(SWT.INHERIT_DEFAULT);

		final Button view = new Button(shell, SWT.PUSH);
		view.setText("view");
		save = new Button(shell, SWT.PUSH);
		save.setText("Save");
		save.setVisible(false);
		delete = new Button(shell, SWT.PUSH);
		delete.setText("Delete");
		delete.setVisible(false);
		removesheet = new Button(shell, SWT.PUSH);
		removesheet.setText("Clear data");
		removesheet.setVisible(false);

		FormData view1 = new FormData(84, 30);
		view1.right = new FormAttachment(80);
		view1.top = new FormAttachment(3);
		view.setLayoutData(view1);

		FormData remove1 = new FormData(84, 30);
		remove1.right = new FormAttachment(80);
		remove1.bottom = new FormAttachment(17);
		removesheet.setLayoutData(remove1);

		FormData save1 = new FormData(80, 30);
		save1.right = new FormAttachment(63);
		save1.bottom = new FormAttachment(65);
		save.setLayoutData(save1);

		FormData delete1 = new FormData(80, 30);
		delete1.right = new FormAttachment(save, -5, SWT.LEFT);
		delete1.bottom = new FormAttachment(save, 0, SWT.BOTTOM);
		delete.setLayoutData(delete1);

		view.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {

				view.setEnabled(false);
				delete.setVisible(true);
				save.setVisible(true);
				removesheet.setVisible(true);
				delete.setEnabled(true);
				save.setEnabled(true);

				ui.viewButtonSelect(shell);

			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {

			}
		});

		shell.setSize(500, 500);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public void viewTable(final Shell shell) throws IOException {

		table = new Table(shell, SWT.CHECK | SWT.BORDER | SWT.V_SCROLL
				| SWT.H_SCROLL);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);

		final TableColumn column1;
		final TableColumn column2;
		final TableColumn column3;
		final TableColumn column4;

		column1 = new TableColumn(table, SWT.READ_ONLY);
		column1.setText("ID");
		column2 = new TableColumn(table, SWT.READ_ONLY);
		column2.setText("Name");
		column3 = new TableColumn(table, SWT.READ_ONLY);
		column3.setText("Type");
		column4 = new TableColumn(table, SWT.READ_ONLY);
		column4.setText("Age");
		column1.setWidth(100);
		column2.setWidth(100);
		column3.setWidth(100);
		column4.setWidth(100);

		ui.test();

		shell.redraw();
		shell.layout();

		save.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {

				TestServiceClass tsc = new TestServiceClass();
				tsc.deleteUnfilledRow();

				TableColumn[] columns = table.getColumns();
				TableItem[] items = table.getItems();
				ArrayList<AnimalModel> animlist = new ArrayList<AnimalModel>();
				AnimalModel am = new AnimalModel();
				for (TableItem item : items) {
					for (int i = 0; i < columns.length; i++) {
						String text = item.getText(i);
						if (!text.equals("")) {

							if (i == 1) {
								am.setName(text);
							}
							if (i == 2) {
								am.setType(text);

							}
							if (i == 3) {
								am.setAge(text);
								// System.out.println(text);
							}

						}
					}

				}

				animlist.add(am);
				TestServiceClass tc = new TestServiceClass();
				tc.insertIntoTable(animlist);
				ui.test();

				// AnimalTable animalTable = new AnimalTable();
				// try {
				// animalTable.viewTable(shell);
				// } catch (IOException e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }

				// AnimalTable ui = new AnimalTable();
				// ui.viewButtonSelect(shell);

				// new MessageBox(shell, SWT.OK).setText("successfully saved");
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {

			}
		});

		removesheet.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				TestServiceClass tsc = new TestServiceClass();
				tsc.removeValues();

			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {

			}
		});

		final Listener changeTableHeight = new Listener() {

			@Override
			public void handleEvent(Event e) {
				e.height = (int) (e.gc.getFontMetrics().getHeight() * 1.5);

			}
		};

		table.addListener(SWT.MeasureItem, changeTableHeight);
		delete.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				/*
				 * AnimalModel am = new AnimalModel(); int selection =
				 * table.getSelectionIndex(); if (selection > -1) { //
				 * System.out.println("selection "+selection); TestServiceClass
				 * tc = new TestServiceClass(); am =
				 * animalModels.get(selection); int id = am.getId(); selection =
				 * id; // if (id > 1) { // id = id + 1; // am =
				 * animalModels.get(selection); // System.out
				 * .println("delete from animal_details where id ='" + id +
				 * "'");
				 * 
				 * // } tc.deleteRow(selection); }
				 */

				int index = table.getSelectionIndex();
				table.remove(table.getSelectionIndices());
				if (index > -1) {
					// .out.println("index "+index);
					TestServiceClass tc = new TestServiceClass();
					tc.deleteRow(index);
					// AnimalTable animalTable = new AnimalTable();
					// animalTable.test(table);

				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {

			}
		});

		final TableEditor editor = new TableEditor(table);
		editor.horizontalAlignment = SWT.LEFT;
		editor.grabHorizontal = true;
		table.addListener(SWT.MouseDown, new Listener() {
			@Override
			public void handleEvent(Event event) {
				Rectangle clientArea = table.getClientArea();
				Point pt = new Point(event.x, event.y);
				int index = table.getTopIndex();
				while (index < table.getItemCount()) {
					boolean visible = false;
					final TableItem item = table.getItem(index);
					for (int i = 0; i < table.getColumnCount(); i++) {
						Rectangle rect = item.getBounds(i);
						if (rect.contains(pt)) {
							final int column = i;
							final Text text = new Text(table, SWT.NONE);
							Listener textListener = new Listener() {
								public void handleEvent(final Event e) {
									switch (e.type) {
									case SWT.FocusOut:
										item.setText(column, text.getText());
										text.dispose();

										break;
									case SWT.Traverse:
										switch (e.detail) {
										case SWT.TRAVERSE_RETURN:
											item.setText(column, text.getText());
											// FALL THROUGH
										case SWT.TRAVERSE_ESCAPE:
											text.dispose();
											e.doit = false;
										}
										break;
									}
								}
							};
							text.addListener(SWT.FocusOut, textListener);
							text.addListener(SWT.Traverse, textListener);
							editor.setEditor(text, item, i);
							text.setText(item.getText(i));
							text.selectAll();
							text.setFocus();
							return;
						}
						if (!visible && rect.intersects(clientArea)) {
							visible = true;
						}
					}
					if (!visible)
						return;
					index++;
				}
			}
		});

		shell.redraw();
		shell.layout();
	}

	public void sqlDelete() {

	}

}
